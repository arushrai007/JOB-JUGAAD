# Job Jugaad 需求文档

## 1. 网站名称
Job Jugaad\n
## 2. 网站描述
一个生产级全栈Web应用，帮助求职者识别技能差距、获取实时学习推荐、职业预测分析、简历ATS优化、薪资估算、文档管理和技能学习时间规划。

## 3. 核心功能
\n### 3.1 高级通知系统
- 多渠道通知：邮件、短信、推送通知
- 个性化内容：职位匹配、网络研讨会、黑客松、技能机会、职业里程碑
- 用户偏好设置与频率控制
- 通知发送分析与追踪

### 3.2 技能差距分析
- 对比用户画像与目标职位\n- 按技能、经验、证书计算精确差距
- 生成差距向量和严重程度评分
- 提供技能提升优先级建议

### 3.3 实时学习推荐
- 即时推荐微课程、文章、视频、迷你项目
- 基于技能差距和用户偏好的混合推荐引擎
- 内容难度分级与学习路径规划
- WebSocket实时推送更新

### 3.4 预测分析
- 职位匹配概率预测（基于技能重叠、经验、证书）
- 薪资范围预测（使用XGBoost/LightGBM模型）
- 晋升概率估算\n- 达到目标角色的预计时间

### 3.5 笔记与PDF管理
- 上传、标注、查看和存储学习笔记与课程PDF
- OCR文本提取功能（Tesseract或Google Vision API）
- 标签组织与高亮功能
- 内联注释器与搜索功能

### 3.6 薪资计算器（Step 1优先交付）
**输入参数：**
- 以往公司列表（公司名称与资历级别）
- 教育背景（最高学位与专业）
- 工作年限\n- 目标职位\n- 编程语言及熟练度（1-5级）
- 编程综合评分（0-100）
- 沟通能力（1-5级）
- 所在国家/城市
- 行业类型（可选）
- 上一家公司规模（可选）
- 证书、作品集、是否愿意搬迁（可选）

**计算逻辑：**
- 基础中位数查询：根据国家、职位、经验年限区间查找市场薪资中位数
- 修正因子：\n  - 教育背景：硕士学位+5-8%
  - 顶级公司背景：FAANG等+8-20%
  - 编程熟练度：按评分调整
  - 沟通能力：客户导向角色加成
  - 热门技术栈：额外加成
  - 搬迁意愿：扩大薪资区间
- 置信度计算：基于市场样本量和匹配精确度
\n**输出结果：**
- 目标职位与地区\n- 市场中位数薪资
- 薪资范围（低-高）
- 估算薪资\n- 百分位排名
- 影响因素分解（各因素贡献百分比）
- 置信度评分（0-100）
\n**UI交互：**
- 模态窗口或独立页面
- 自动填充用户画像数据
- 经验与沟通能力滑块（实时气泡提示）
- 编程语言多选标签（显示熟练度）
- 国家下拉菜单+城市自动补全
- 提交后动画加载器→结果卡片动画展示
-薪资数字、范围、置信度仪表盘（动画环形图）
- 可折叠'计算方式'说明（柱状图显示各因素贡献）
- CTA按钮：保存估算/获取职业规划/对比顶级公司

### 3.7 简历ATS评分器\n- 上传简历（PDF/DOCX）并解析章节（工作经历、教育、技能、项目）
- 与职位描述对比关键词匹配度（词形还原、权重计算）
- 检测章节完整性、标题规范、格式问题
- 输出ATS评分（0-100）
- 提供缺失关键词列表
- 格式警告与改进建议
-逐行操作清单：添加关键词、调整章节顺序、优化段落长度

### 3.8 技能学习时间规划器
- 输入目标职位与当前画像
- 计算每项缺失技能所需学习时长（难度系数×差距等级×标准学时）
- 估算达到资格所需月数（总学时÷每周学习时长×4）
- 生成分步学习计划（里程碑与检查点）
- 提供强化版与稳定版学习路径
- 显示置信区间\n\n### 3.9 职位搜索\n- 职位搜索与多维度筛选
- ElasticSearch支持全文检索
- 职位模板匹配与推荐
\n### 3.10 用户认证与授权
- OAuth2 + JWT认证
- 基于角色的访问控制\n- 支持Auth0/Firebase Auth或自定义实现
\n## 4. 数据模型

### 4.1 核心实体
- **User（用户）**：id、姓名、邮箱、手机、地区、时区、教育背景、工作经历、技能、编程语言、沟通评分、通知偏好\n- **Experience（工作经历）**：公司、职位、起止日期、资历级别、行业\n- **JobTemplate（职位模板）**：id、标题、地区、必需技能（技能+等级）、加分项、薪资范围、公司规模、行业、职位描述文本
- **Resume（简历）**：上传文件、解析文本、解析章节、ATS评分、最后扫描日期
- **LearningItem（学习资源）**：id、标题、类型（课程/文章/视频）、覆盖技能、时长、来源、难度\n- **Notification（通知）**：id、用户id、类型、渠道、内容、发送时间、状态
- **SalaryMarket（薪资市场数据）**：地区、职位、中位数、25分位、75分位、样本量、数据日期

## 5. API端点

### 5.1 认证\n- POST /api/auth/register — 用户注册
- POST /api/auth/login — 登录（返回JWT）
\n### 5.2 用户管理
- GET /api/user/me — 获取当前用户画像
- PUT /api/user/me — 更新画像（教育、经历、技能、编程熟练度）
\n### 5.3 简历与ATS
- POST /api/resume/upload — 上传简历（触发解析+ATS评分）
- POST /api/ats/score — 评估简历vs职位描述（返回评分+建议）

### 5.4 薪资计算
- POST /api/salary/estimate — 薪资计算器（输入：经历、教育、语言、地区、职位、沟通能力、以往公司）→ 返回薪资估算+置信度+分解\n
### 5.5 技能与推荐
- POST /api/skillgap — 对比用户vs职位模板 → 返回技能差距向量、严重程度、推荐资源
- GET /api/recommendations/real-time — 返回排序后的学习资源（实时、个性化）

### 5.6 通知\n- POST /api/notifications/send — 发送通知（管理员/测试）
\n### 5.7 预测分析
- GET /api/analytics/predict — 用户预测分析（职位匹配概率、达到目标时间）

### 5.8 笔记管理
- POST /api/notes/upload — 上传PDF/标注/提取文本\n\n### 5.9 职位搜索
- GET /api/jobs/search — 职位搜索+筛选

### 5.10 实时通信
- WebSocket /ws/realtime — 推送实时推荐/通知

## 6. 技术栈

### 6.1 前端\n- React + Vite\n- TypeScript
- TailwindCSS
- Framer Motion（动画）
- Recharts或ECharts（图表）
\n### 6.2 后端
- Node.js（NestJS或Express）或Python（FastAPI）
- REST API + GraphQL（可选）
\n### 6.3 数据库
- PostgreSQL（关系型数据）
- Redis（缓存）
- ElasticSearch（简历/职位搜索）
\n### 6.4 机器学习
- Python（scikit-learn、XGBoost/LightGBM、PyTorch）
- FastAPI或TorchServe模型服务

### 6.5 通知服务
- SendGrid/Mailgun（邮件）
- Twilio（短信）
- Firebase Cloud Messaging（推送）

### 6.6 文件存储
- S3兼容存储（AWS S3/MinIO）
\n### 6.7 部署
- Docker容器化
- Kubernetes（可选）或托管服务（Heroku/AWS ECS）\n- CI/CD：GitHub Actions/GitLab CI\n
### 6.8 认证
- Auth0/Firebase Auth或自定义OAuth2/JWT
\n### 6.9 OCR/文本提取
- Tesseract或Google Vision API\n\n## 7. 非功能性需求
\n### 7.1 架构
- 生产就绪架构：容器化服务（Docker）、CI/CD、安全API、自动化测试、分级环境（staging+production）
- 可扩展：微服务友好、ML模型服务（REST或FastAPI+模型服务器）\n\n### 7.2 安全性
- OAuth2 + JWT认证
- 基于角色的访问控制
- 数据加密\n- GDPR/PDPA合规的数据同意机制

### 7.3 用户体验
- 动画效果丰富、现代化设计
- 深色/浅色主题切换\n- 无障碍访问（WCAG AA标准）
- 移动优先、响应式设计
\n### 7.4 可观测性
- 日志记录\n- 监控\n- 错误追踪
\n### 7.5 国际化
- 支持i18n\n- 时区感知
\n## 8. 网站设计风格

### 8.1 配色方案
- 主色调：专业蓝（#2563EB）与科技紫（#7C3AED）渐变，传递职业发展与智能科技感
- 辅助色：成功绿（#10B981）用于进度与成就，警示橙（#F59E0B）用于待改进项
- 背景：深色模式采用深灰（#1F2937）+浅色模式采用浅灰白（#F9FAFB）
\n### 8.2 布局方式
- 左侧导航栏+主内容区仪表盘布局
- 卡片式模块化设计，清晰分隔各功能区
- 网格式排列KPI指标与图表

### 8.3 视觉细节
- 圆角弧度：8px中等圆角，营造现代友好感
- 阴影层次：卡片悬浮阴影（hover时加深），增强层次感
- 图标风格：线性图标（Heroicons或Lucide），保持简洁一致
- 动画效果：Framer Motion实现页面切换、卡片展开、进度条填充、数字滚动等流畅过渡动画

### 8.4 交互微动效
- 按钮悬停阴影加深与轻微放大
- 加载骨架屏（skeleton loading）
- 进度环形图动画填充
- 薪资结果卡片从下向上滑入
- 通知气泡弹出动画
-拖拽上传简历时边框高亮与虚线动画

## 9. 交付物

### 9.1 代码与部署
- 完整源代码（前端+后端+ML notebooks）
- Dockerfiles与基础部署脚本
- 本地运行与staging部署Runbook
\n### 9.2 测试
- 单元测试\n- 基础集成测试
\n### 9.3 文档
- OpenAPI/Swagger API文档
- 架构文档
- 数据模式说明
- 开发者笔记（如何接入真实市场数据集）
- README（本地启动与部署指南）
-薪资模型计算逻辑说明（公式/权重）

### 9.4 设计资产
- Figma或等效设计稿（可选但推荐）
\n## 10. 验收标准

### 10.1 Step 1（薪资计算器）验收清单
- 后端POST /api/salary/estimate对相同输入返回确定性结果，包含置信度与分解
- 前端表单验证并发送JSON，显示动画结果卡片，结果存储至数据库
- 基础单元测试覆盖端点，集成测试覆盖前后端流程
- 文档说明本地运行方法与薪资模型工作原理（公式/权重）
- Step 1可使用基于规则的实现，预留ML模型替换接口

### 10.2 整体项目KPI\n- 端到端薪资计算器正常工作并集成至仪表盘
- 简历ATS评分+建议适用于90%常见简历格式
- 技能差距分析正确映射技能至目标职位，推荐显示相关学习资源
- 实时推荐响应时间：缓存数据<1秒，新计算<3秒\n- 通知按配置发送并追踪\n
## 11. 可选增强功能（Phase 2+）
- 基于ML的薪资模型+SHAP可解释性\n- 集成LinkedIn API进行简历丰富\n- 雇主仪表盘（发布职位与匹配用户）
- 浏览器扩展（原地评分职位/简历）
\n## 12. 示例数据

### 12.1 薪资估算请求示例
```json\n{
  \"previous_companies\": [{\"name\":\"Zeta Labs\", \"seniority\":\"Senior Engineer\"}],
  \"education\": {\"degree\":\"B.Tech\", \"field\":\"Computer Science\"},
  \"years_experience\": 4,
  \"role_target\": \"Backend Engineer\",
  \"coding_languages\": [{\"name\":\"Java\", \"level\":5}, {\"name\":\"Python\", \"level\":4}],
  \"coding_fluency_score\": 86,
  \"communication_skill\": 4,
  \"location_country\": \"India\",
  \"industry\": \"SaaS\",
  \"certifications\": [\"AWS Certified Developer\"],
  \"open_to_relocate\": true\n}
```

### 12.2 薪资估算响应示例\n```json
{
  \"role\": \"Backend Engineer\",
  \"location\": \"India\",
  \"median_salary\": 1800000,
  \"salary_range\": {\"low\": 1400000, \"high\": 2300000},
  \"estimated_salary\": 1950000,
  \"percentile\": 62,
  \"feature_breakdown\": [\n    {\"factor\":\"years_experience\", \"impact_percent\": 8},
    {\"factor\":\"education\", \"impact_percent\": 4},
    {\"factor\":\"prev_company\",\"impact_percent\": 12},
    {\"factor\":\"coding_fluency\",\"impact_percent\": 5}\n  ],
  \"confidence\": 74\n}
```