import { supabase } from './supabase';
import type {
  Profile,
  Experience,
  Education,
  Skill,
  Certification,
  JobTemplate,
  SalaryMarketData,
  Resume,
  LearningResource,
  Notification,
  UserPreferences,
  SalaryEstimate,
  SalaryEstimateRequest,
  SalaryEstimateResponse
} from '@/types/types';

export const api = {
  // Profile APIs
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
    return data;
  },

  async updateProfile(userId: string, updates: Partial<Profile>): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating profile:', error);
      return null;
    }
    return data;
  },

  async getAllProfiles(): Promise<Profile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching profiles:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  // Experience APIs
  async getExperiences(userId: string): Promise<Experience[]> {
    const { data, error } = await supabase
      .from('experiences')
      .select('*')
      .eq('user_id', userId)
      .order('start_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching experiences:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createExperience(experience: Omit<Experience, 'id' | 'created_at'>): Promise<Experience | null> {
    const { data, error } = await supabase
      .from('experiences')
      .insert(experience)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating experience:', error);
      return null;
    }
    return data;
  },

  async updateExperience(id: string, updates: Partial<Experience>): Promise<Experience | null> {
    const { data, error } = await supabase
      .from('experiences')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating experience:', error);
      return null;
    }
    return data;
  },

  async deleteExperience(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('experiences')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting experience:', error);
      return false;
    }
    return true;
  },

  // Education APIs
  async getEducation(userId: string): Promise<Education[]> {
    const { data, error } = await supabase
      .from('education')
      .select('*')
      .eq('user_id', userId)
      .order('graduation_year', { ascending: false });
    
    if (error) {
      console.error('Error fetching education:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createEducation(education: Omit<Education, 'id' | 'created_at'>): Promise<Education | null> {
    const { data, error } = await supabase
      .from('education')
      .insert(education)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating education:', error);
      return null;
    }
    return data;
  },

  async updateEducation(id: string, updates: Partial<Education>): Promise<Education | null> {
    const { data, error } = await supabase
      .from('education')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating education:', error);
      return null;
    }
    return data;
  },

  async deleteEducation(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('education')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting education:', error);
      return false;
    }
    return true;
  },

  // Skills APIs
  async getSkills(userId: string): Promise<Skill[]> {
    const { data, error } = await supabase
      .from('skills')
      .select('*')
      .eq('user_id', userId)
      .order('proficiency_level', { ascending: false });
    
    if (error) {
      console.error('Error fetching skills:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createSkill(skill: Omit<Skill, 'id' | 'created_at'>): Promise<Skill | null> {
    const { data, error } = await supabase
      .from('skills')
      .insert(skill)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating skill:', error);
      return null;
    }
    return data;
  },

  async updateSkill(id: string, updates: Partial<Skill>): Promise<Skill | null> {
    const { data, error } = await supabase
      .from('skills')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating skill:', error);
      return null;
    }
    return data;
  },

  async deleteSkill(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('skills')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting skill:', error);
      return false;
    }
    return true;
  },

  // Certifications APIs
  async getCertifications(userId: string): Promise<Certification[]> {
    const { data, error } = await supabase
      .from('certifications')
      .select('*')
      .eq('user_id', userId)
      .order('issue_date', { ascending: false });
    
    if (error) {
      console.error('Error fetching certifications:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createCertification(certification: Omit<Certification, 'id' | 'created_at'>): Promise<Certification | null> {
    const { data, error } = await supabase
      .from('certifications')
      .insert(certification)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating certification:', error);
      return null;
    }
    return data;
  },

  async updateCertification(id: string, updates: Partial<Certification>): Promise<Certification | null> {
    const { data, error } = await supabase
      .from('certifications')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating certification:', error);
      return null;
    }
    return data;
  },

  async deleteCertification(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('certifications')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('Error deleting certification:', error);
      return false;
    }
    return true;
  },

  // Job Templates APIs
  async getJobTemplates(limit = 20, offset = 0): Promise<JobTemplate[]> {
    const { data, error } = await supabase
      .from('job_templates')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      console.error('Error fetching job templates:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async getJobTemplate(id: string): Promise<JobTemplate | null> {
    const { data, error } = await supabase
      .from('job_templates')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching job template:', error);
      return null;
    }
    return data;
  },

  // Salary Market Data APIs
  async getSalaryMarketData(
    jobTitle: string,
    country: string,
    experienceYears: number
  ): Promise<SalaryMarketData | null> {
    const { data, error } = await supabase
      .from('salary_market_data')
      .select('*')
      .eq('job_title', jobTitle)
      .eq('location_country', country)
      .lte('experience_min', experienceYears)
      .gte('experience_max', experienceYears)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching salary market data:', error);
      return null;
    }
    return data;
  },

  // Resumes APIs
  async getResumes(userId: string): Promise<Resume[]> {
    const { data, error } = await supabase
      .from('resumes')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching resumes:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createResume(resume: Omit<Resume, 'id' | 'created_at'>): Promise<Resume | null> {
    const { data, error } = await supabase
      .from('resumes')
      .insert(resume)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating resume:', error);
      return null;
    }
    return data;
  },

  async updateResume(id: string, updates: Partial<Resume>): Promise<Resume | null> {
    const { data, error } = await supabase
      .from('resumes')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating resume:', error);
      return null;
    }
    return data;
  },

  // Learning Resources APIs
  async getLearningResources(
    skills?: string[],
    difficultyLevel?: number,
    limit = 20,
    offset = 0
  ): Promise<LearningResource[]> {
    let query = supabase
      .from('learning_resources')
      .select('*');
    
    if (skills && skills.length > 0) {
      query = query.contains('covered_skills', skills);
    }
    
    if (difficultyLevel) {
      query = query.eq('difficulty_level', difficultyLevel);
    }
    
    const { data, error } = await query
      .order('rating', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      console.error('Error fetching learning resources:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  // Notifications APIs
  async getNotifications(userId: string, limit = 50, offset = 0): Promise<Notification[]> {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      console.error('Error fetching notifications:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async markNotificationAsRead(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString(), status: 'read' })
      .eq('id', id);
    
    if (error) {
      console.error('Error marking notification as read:', error);
      return false;
    }
    return true;
  },

  // User Preferences APIs
  async getUserPreferences(userId: string): Promise<UserPreferences | null> {
    const { data, error } = await supabase
      .from('user_preferences')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching user preferences:', error);
      return null;
    }
    return data;
  },

  async updateUserPreferences(userId: string, updates: Partial<UserPreferences>): Promise<UserPreferences | null> {
    const { data, error } = await supabase
      .from('user_preferences')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error updating user preferences:', error);
      return null;
    }
    return data;
  },

  // Salary Estimates APIs
  async getSalaryEstimates(userId: string, limit = 20, offset = 0): Promise<SalaryEstimate[]> {
    const { data, error } = await supabase
      .from('salary_estimates')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    if (error) {
      console.error('Error fetching salary estimates:', error);
      return [];
    }
    return Array.isArray(data) ? data : [];
  },

  async createSalaryEstimate(estimate: Omit<SalaryEstimate, 'id' | 'created_at'>): Promise<SalaryEstimate | null> {
    const { data, error } = await supabase
      .from('salary_estimates')
      .insert(estimate)
      .select()
      .maybeSingle();
    
    if (error) {
      console.error('Error creating salary estimate:', error);
      return null;
    }
    return data;
  },

  // Salary Calculation Logic
  calculateSalaryEstimate(request: SalaryEstimateRequest): SalaryEstimateResponse {
    const {
      role_target,
      location_country,
      location_city,
      years_experience,
      education,
      previous_companies,
      coding_languages,
      coding_fluency_score,
      communication_skill,
      industry,
      certifications = [],
      open_to_relocate
    } = request;

    // Base median salary lookup (simplified - in production, query salary_market_data table)
    const baseSalaries: { [key: string]: { [key: string]: number } } = {
      'USA': {
        'Backend Engineer': 160000,
        'Frontend Engineer': 155000,
        'Full Stack Engineer': 165000,
        'Data Scientist': 170000,
        'DevOps Engineer': 165000
      },
      'India': {
        'Backend Engineer': 1800000,
        'Frontend Engineer': 1700000,
        'Full Stack Engineer': 2000000,
        'Data Scientist': 2100000,
        'DevOps Engineer': 1900000
      },
      'UK': {
        'Backend Engineer': 65000,
        'Frontend Engineer': 62000,
        'Full Stack Engineer': 70000,
        'Data Scientist': 72000,
        'DevOps Engineer': 68000
      }
    };

    const medianSalary = baseSalaries[location_country]?.[role_target] || 100000;
    let estimatedSalary = medianSalary;
    const featureBreakdown: { factor: string; impact_percent: number }[] = [];

    // Education factor
    let educationMultiplier = 1.0;
    if (education.degree.includes('M.') || education.degree.includes('Master')) {
      educationMultiplier = 1.06;
      featureBreakdown.push({ factor: 'education', impact_percent: 6 });
    } else if (education.degree.includes('Ph.D') || education.degree.includes('Doctorate')) {
      educationMultiplier = 1.08;
      featureBreakdown.push({ factor: 'education', impact_percent: 8 });
    } else {
      featureBreakdown.push({ factor: 'education', impact_percent: 0 });
    }
    estimatedSalary *= educationMultiplier;

    // Previous company factor (FAANG/top companies)
    const topCompanies = ['Google', 'Facebook', 'Meta', 'Amazon', 'Apple', 'Microsoft', 'Netflix', 'FAANG'];
    const hasTopCompany = previous_companies.some(c => 
      topCompanies.some(top => c.name.toLowerCase().includes(top.toLowerCase()))
    );
    if (hasTopCompany) {
      const companyMultiplier = 1.15;
      estimatedSalary *= companyMultiplier;
      featureBreakdown.push({ factor: 'prev_company', impact_percent: 15 });
    } else {
      featureBreakdown.push({ factor: 'prev_company', impact_percent: 0 });
    }

    // Coding fluency factor
    if (coding_fluency_score >= 80) {
      const codingMultiplier = 1.08;
      estimatedSalary *= codingMultiplier;
      featureBreakdown.push({ factor: 'coding_fluency', impact_percent: 8 });
    } else if (coding_fluency_score >= 60) {
      const codingMultiplier = 1.04;
      estimatedSalary *= codingMultiplier;
      featureBreakdown.push({ factor: 'coding_fluency', impact_percent: 4 });
    } else {
      featureBreakdown.push({ factor: 'coding_fluency', impact_percent: 0 });
    }

    // Communication skill factor
    if (communication_skill >= 4) {
      const commMultiplier = 1.05;
      estimatedSalary *= commMultiplier;
      featureBreakdown.push({ factor: 'communication', impact_percent: 5 });
    } else {
      featureBreakdown.push({ factor: 'communication', impact_percent: 0 });
    }

    // Years of experience factor
    const experienceMultiplier = 1 + (years_experience * 0.03);
    estimatedSalary *= experienceMultiplier;
    featureBreakdown.push({ factor: 'years_experience', impact_percent: Math.round(years_experience * 3) });

    // Hot tech stack factor
    const hotTechs = ['React', 'Node.js', 'Python', 'Kubernetes', 'AWS', 'TypeScript', 'Go'];
    const hasHotTech = coding_languages.some(lang => 
      hotTechs.some(hot => lang.name.toLowerCase().includes(hot.toLowerCase())) && lang.level >= 4
    );
    if (hasHotTech) {
      const techMultiplier = 1.06;
      estimatedSalary *= techMultiplier;
      featureBreakdown.push({ factor: 'hot_tech_stack', impact_percent: 6 });
    } else {
      featureBreakdown.push({ factor: 'hot_tech_stack', impact_percent: 0 });
    }

    // Certifications factor
    if (certifications.length > 0) {
      const certMultiplier = 1 + (certifications.length * 0.02);
      estimatedSalary *= certMultiplier;
      featureBreakdown.push({ factor: 'certifications', impact_percent: certifications.length * 2 });
    } else {
      featureBreakdown.push({ factor: 'certifications', impact_percent: 0 });
    }

    // Calculate salary range
    const rangeLow = Math.round(estimatedSalary * 0.85);
    const rangeHigh = Math.round(estimatedSalary * 1.15);

    // Relocation willingness expands range
    const finalRangeLow = open_to_relocate ? Math.round(rangeLow * 0.95) : rangeLow;
    const finalRangeHigh = open_to_relocate ? Math.round(rangeHigh * 1.05) : rangeHigh;

    // Calculate percentile (simplified)
    const percentile = Math.min(95, Math.max(25, Math.round(50 + (estimatedSalary - medianSalary) / medianSalary * 100)));

    // Calculate confidence score
    let confidence = 70;
    if (previous_companies.length > 0) confidence += 10;
    if (coding_languages.length >= 3) confidence += 10;
    if (certifications.length > 0) confidence += 5;
    if (years_experience >= 3) confidence += 5;
    confidence = Math.min(100, confidence);

    // Determine currency
    const currencyMap: { [key: string]: string } = {
      'USA': 'USD',
      'India': 'INR',
      'UK': 'GBP',
      'Germany': 'EUR'
    };
    const currency = currencyMap[location_country] || 'USD';

    return {
      role: role_target,
      location: location_city ? `${location_city}, ${location_country}` : location_country,
      median_salary: Math.round(medianSalary),
      salary_range: {
        low: finalRangeLow,
        high: finalRangeHigh
      },
      estimated_salary: Math.round(estimatedSalary),
      percentile,
      feature_breakdown: featureBreakdown,
      confidence,
      currency
    };
  }
};
