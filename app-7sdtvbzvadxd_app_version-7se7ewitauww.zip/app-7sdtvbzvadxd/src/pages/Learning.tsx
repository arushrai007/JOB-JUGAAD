import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { GraduationCap, Clock, Star, ExternalLink } from 'lucide-react';

const Learning = () => {
  const mockResources = [
    {
      title: 'Complete Python Bootcamp',
      provider: 'Udemy',
      type: 'Course',
      duration: '40 hours',
      rating: 4.6,
      difficulty: 'Intermediate',
      skills: ['Python', 'Programming'],
      isFree: false
    },
    {
      title: 'React - The Complete Guide',
      provider: 'Udemy',
      type: 'Course',
      duration: '48 hours',
      rating: 4.8,
      difficulty: 'Advanced',
      skills: ['React', 'JavaScript'],
      isFree: false
    },
    {
      title: 'Python for Data Science',
      provider: 'Coursera',
      type: 'Course',
      duration: '25 hours',
      rating: 4.5,
      difficulty: 'Intermediate',
      skills: ['Python', 'Data Science'],
      isFree: true
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 animate-fade-in">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl gradient-primary">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Learning Resources</h1>
            <p className="text-muted-foreground">Curated courses to boost your skills</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockResources.map((resource, index) => (
          <Card key={index} className="animate-slide-up hover:shadow-elegant transition-smooth" style={{ animationDelay: `${index * 0.1}s` }}>
            <CardHeader>
              <div className="flex items-start justify-between mb-2">
                <Badge variant={resource.isFree ? 'default' : 'secondary'}>
                  {resource.isFree ? 'Free' : 'Paid'}
                </Badge>
                <div className="flex items-center gap-1 text-sm">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span>{resource.rating}</span>
                </div>
              </div>
              <CardTitle className="text-lg">{resource.title}</CardTitle>
              <CardDescription>{resource.provider}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {resource.duration}
                </div>
                <Badge variant="outline" className="text-xs">
                  {resource.difficulty}
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {resource.skills.map((skill, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">{skill}</Badge>
                ))}
              </div>
              <Button className="w-full gap-2" variant="outline">
                <ExternalLink className="w-4 h-4" />
                View Course
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Learning;
