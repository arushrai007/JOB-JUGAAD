import { useState } from 'react';
import { useAuth } from 'miaoda-auth-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { Calculator, TrendingUp, Award, Briefcase, GraduationCap, Code, MessageSquare, MapPin, Plus, X, Loader2 } from 'lucide-react';
import { api } from '@/db/api';
import type { SalaryEstimateRequest, SalaryEstimateResponse, PreviousCompany, CodingLanguage } from '@/types/types';

const SalaryCalculator = () => {
  const { user } = useAuth();
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<SalaryEstimateResponse | null>(null);

  const [formData, setFormData] = useState<SalaryEstimateRequest>({
    previous_companies: [],
    education: { degree: '', field: '' },
    years_experience: 0,
    role_target: '',
    coding_languages: [],
    coding_fluency_score: 50,
    communication_skill: 3,
    location_country: '',
    location_city: '',
    industry: '',
    certifications: [],
    open_to_relocate: false
  });

  const [newCompany, setNewCompany] = useState({ name: '', seniority: '' });
  const [newLanguage, setNewLanguage] = useState({ name: '', level: 3 });
  const [newCertification, setNewCertification] = useState('');

  const addCompany = () => {
    if (newCompany.name && newCompany.seniority) {
      setFormData({
        ...formData,
        previous_companies: [...formData.previous_companies, newCompany]
      });
      setNewCompany({ name: '', seniority: '' });
    }
  };

  const removeCompany = (index: number) => {
    setFormData({
      ...formData,
      previous_companies: formData.previous_companies.filter((_, i) => i !== index)
    });
  };

  const addLanguage = () => {
    if (newLanguage.name) {
      setFormData({
        ...formData,
        coding_languages: [...formData.coding_languages, newLanguage]
      });
      setNewLanguage({ name: '', level: 3 });
    }
  };

  const removeLanguage = (index: number) => {
    setFormData({
      ...formData,
      coding_languages: formData.coding_languages.filter((_, i) => i !== index)
    });
  };

  const addCertification = () => {
    if (newCertification) {
      setFormData({
        ...formData,
        certifications: [...(formData.certifications || []), newCertification]
      });
      setNewCertification('');
    }
  };

  const removeCertification = (index: number) => {
    setFormData({
      ...formData,
      certifications: formData.certifications?.filter((_, i) => i !== index) || []
    });
  };

  const handleCalculate = async () => {
    if (!formData.role_target || !formData.location_country || !formData.education.degree) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsCalculating(true);

    try {
      const estimateResult = api.calculateSalaryEstimate(formData);
      setResult(estimateResult);

      if (user) {
        await api.createSalaryEstimate({
          user_id: user.id,
          role_target: formData.role_target,
          location_country: formData.location_country,
          location_city: formData.location_city,
          years_experience: formData.years_experience,
          education_degree: formData.education.degree,
          education_field: formData.education.field,
          previous_companies: formData.previous_companies,
          coding_languages: formData.coding_languages,
          coding_fluency_score: formData.coding_fluency_score,
          communication_skill: formData.communication_skill,
          industry: formData.industry,
          certifications: formData.certifications || [],
          open_to_relocate: formData.open_to_relocate,
          estimated_salary: estimateResult.estimated_salary,
          salary_range_low: estimateResult.salary_range.low,
          salary_range_high: estimateResult.salary_range.high,
          median_salary: estimateResult.median_salary,
          percentile: estimateResult.percentile,
          confidence_score: estimateResult.confidence,
          feature_breakdown: estimateResult.feature_breakdown
        });
      }

      toast.success('Salary estimate calculated successfully!');
    } catch (error) {
      console.error('Error calculating salary:', error);
      toast.error('Failed to calculate salary estimate');
    } finally {
      setIsCalculating(false);
    }
  };

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8 animate-fade-in">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl gradient-primary">
            <Calculator className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Salary Calculator</h1>
            <p className="text-muted-foreground">Get accurate salary estimates based on your profile</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card className="animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Basic Information
              </CardTitle>
              <CardDescription>Tell us about your target role and location</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Target Role *</Label>
                  <Select value={formData.role_target} onValueChange={(value) => setFormData({ ...formData, role_target: value })}>
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Backend Engineer">Backend Engineer</SelectItem>
                      <SelectItem value="Frontend Engineer">Frontend Engineer</SelectItem>
                      <SelectItem value="Full Stack Engineer">Full Stack Engineer</SelectItem>
                      <SelectItem value="Data Scientist">Data Scientist</SelectItem>
                      <SelectItem value="DevOps Engineer">DevOps Engineer</SelectItem>
                      <SelectItem value="Mobile Developer">Mobile Developer</SelectItem>
                      <SelectItem value="Product Manager">Product Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country">Country *</Label>
                  <Select value={formData.location_country} onValueChange={(value) => setFormData({ ...formData, location_country: value })}>
                    <SelectTrigger id="country">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USA">United States</SelectItem>
                      <SelectItem value="India">India</SelectItem>
                      <SelectItem value="UK">United Kingdom</SelectItem>
                      <SelectItem value="Germany">Germany</SelectItem>
                      <SelectItem value="Canada">Canada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city">City (Optional)</Label>
                  <Input
                    id="city"
                    placeholder="e.g., San Francisco"
                    value={formData.location_city}
                    onChange={(e) => setFormData({ ...formData, location_city: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="industry">Industry (Optional)</Label>
                  <Input
                    id="industry"
                    placeholder="e.g., FinTech, SaaS"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Years of Experience: {formData.years_experience}</Label>
                <Slider
                  value={[formData.years_experience]}
                  onValueChange={(value) => setFormData({ ...formData, years_experience: value[0] })}
                  max={20}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0 years</span>
                  <span>20+ years</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Education */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Education
              </CardTitle>
              <CardDescription>Your educational background</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="degree">Highest Degree *</Label>
                  <Select value={formData.education.degree} onValueChange={(value) => setFormData({ ...formData, education: { ...formData.education, degree: value } })}>
                    <SelectTrigger id="degree">
                      <SelectValue placeholder="Select degree" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="High School">High School</SelectItem>
                      <SelectItem value="B.Tech">B.Tech / B.E.</SelectItem>
                      <SelectItem value="B.S.">B.S. / B.Sc.</SelectItem>
                      <SelectItem value="M.Tech">M.Tech / M.E.</SelectItem>
                      <SelectItem value="M.S.">M.S. / M.Sc.</SelectItem>
                      <SelectItem value="MBA">MBA</SelectItem>
                      <SelectItem value="Ph.D.">Ph.D.</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="field">Field of Study</Label>
                  <Input
                    id="field"
                    placeholder="e.g., Computer Science"
                    value={formData.education.field}
                    onChange={(e) => setFormData({ ...formData, education: { ...formData.education, field: e.target.value } })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Previous Companies */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Previous Companies
              </CardTitle>
              <CardDescription>Add your work history</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2 mb-4">
                {formData.previous_companies.map((company, index) => (
                  <Badge key={index} variant="secondary" className="gap-2 py-2 px-3">
                    <span>{company.name} ({company.seniority})</span>
                    <button type="button" onClick={() => removeCompany(index)} className="hover:text-destructive">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <Input
                  placeholder="Company name"
                  value={newCompany.name}
                  onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })}
                />
                <Input
                  placeholder="Seniority level"
                  value={newCompany.seniority}
                  onChange={(e) => setNewCompany({ ...newCompany, seniority: e.target.value })}
                />
                <Button type="button" onClick={addCompany} variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Coding Languages */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                Programming Languages
              </CardTitle>
              <CardDescription>Your technical skills and proficiency</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2 mb-4">
                {formData.coding_languages.map((lang, index) => (
                  <Badge key={index} variant="secondary" className="gap-2 py-2 px-3">
                    <span>{lang.name} (Level {lang.level})</span>
                    <button type="button" onClick={() => removeLanguage(index)} className="hover:text-destructive">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <Input
                  placeholder="Language name"
                  value={newLanguage.name}
                  onChange={(e) => setNewLanguage({ ...newLanguage, name: e.target.value })}
                />
                <Select value={newLanguage.level.toString()} onValueChange={(value) => setNewLanguage({ ...newLanguage, level: parseInt(value) })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Level 1 - Beginner</SelectItem>
                    <SelectItem value="2">Level 2 - Basic</SelectItem>
                    <SelectItem value="3">Level 3 - Intermediate</SelectItem>
                    <SelectItem value="4">Level 4 - Advanced</SelectItem>
                    <SelectItem value="5">Level 5 - Expert</SelectItem>
                  </SelectContent>
                </Select>
                <Button type="button" onClick={addLanguage} variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Overall Coding Fluency: {formData.coding_fluency_score}/100</Label>
                <Slider
                  value={[formData.coding_fluency_score]}
                  onValueChange={(value) => setFormData({ ...formData, coding_fluency_score: value[0] })}
                  max={100}
                  step={1}
                  className="w-full"
                />
              </div>
            </CardContent>
          </Card>

          {/* Communication & Certifications */}
          <Card className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Communication & Certifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Communication Skill: {formData.communication_skill}/5</Label>
                <Slider
                  value={[formData.communication_skill]}
                  onValueChange={(value) => setFormData({ ...formData, communication_skill: value[0] })}
                  max={5}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Poor</span>
                  <span>Excellent</span>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Certifications</Label>
                <div className="flex flex-wrap gap-2 mb-4">
                  {formData.certifications?.map((cert, index) => (
                    <Badge key={index} variant="secondary" className="gap-2 py-2 px-3">
                      <Award className="w-3 h-3" />
                      <span>{cert}</span>
                      <button type="button" onClick={() => removeCertification(index)} className="hover:text-destructive">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Input
                    placeholder="Certification name"
                    value={newCertification}
                    onChange={(e) => setNewCertification(e.target.value)}
                  />
                  <Button type="button" onClick={addCertification} variant="outline" className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="relocate">Open to Relocate</Label>
                  <p className="text-sm text-muted-foreground">Willing to move for the right opportunity</p>
                </div>
                <Switch
                  id="relocate"
                  checked={formData.open_to_relocate}
                  onCheckedChange={(checked) => setFormData({ ...formData, open_to_relocate: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <Button onClick={handleCalculate} disabled={isCalculating} className="w-full h-12 text-lg gap-2">
            {isCalculating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Calculating...
              </>
            ) : (
              <>
                <Calculator className="w-5 h-5" />
                Calculate Salary Estimate
              </>
            )}
          </Button>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-1">
          <div className="sticky top-20">
            {result ? (
              <Card className="animate-scale-in shadow-elegant">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Salary Estimate
                  </CardTitle>
                  <CardDescription>{result.role} in {result.location}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center p-6 rounded-lg gradient-primary">
                    <p className="text-sm text-white/80 mb-2">Estimated Salary</p>
                    <p className="text-4xl font-bold text-white">
                      {formatCurrency(result.estimated_salary, result.currency)}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Salary Range</span>
                        <span className="font-medium">
                          {formatCurrency(result.salary_range.low, result.currency)} - {formatCurrency(result.salary_range.high, result.currency)}
                        </span>
                      </div>
                      <Progress value={50} className="h-2" />
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Market Median</span>
                      <span className="font-medium">{formatCurrency(result.median_salary, result.currency)}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Percentile Rank</span>
                      <Badge variant="secondary">{result.percentile}th</Badge>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Confidence Score</span>
                      <div className="flex items-center gap-2">
                        <Progress value={result.confidence} className="w-20 h-2" />
                        <span className="text-sm font-medium">{result.confidence}%</span>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <p className="text-sm font-medium">Impact Factors</p>
                    {result.feature_breakdown
                      .filter(f => f.impact_percent > 0)
                      .sort((a, b) => b.impact_percent - a.impact_percent)
                      .map((feature, index) => (
                        <div key={index} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground capitalize">
                              {feature.factor.replace(/_/g, ' ')}
                            </span>
                            <span className="font-medium">+{feature.impact_percent}%</span>
                          </div>
                          <Progress value={feature.impact_percent * 2} className="h-1" />
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Results</CardTitle>
                  <CardDescription>Fill in the form and calculate to see your salary estimate</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                      <Calculator className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Your salary estimate will appear here
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalaryCalculator;
