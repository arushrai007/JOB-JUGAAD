import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Briefcase, MapPin, DollarSign } from 'lucide-react';

const Jobs = () => {
  const mockJobs = [
    {
      title: 'Backend Engineer',
      company: 'Tech Corp',
      location: 'San Francisco, USA',
      salary: '$140k - $200k',
      skills: ['Java', 'Spring Boot', 'SQL', 'AWS']
    },
    {
      title: 'Frontend Engineer',
      company: 'Startup Inc',
      location: 'Bangalore, India',
      salary: '₹14L - ₹23L',
      skills: ['React', 'TypeScript', 'CSS', 'Next.js']
    },
    {
      title: 'Full Stack Engineer',
      company: 'FinTech Solutions',
      location: 'New York, USA',
      salary: '$130k - $180k',
      skills: ['Node.js', 'React', 'MongoDB', 'Docker']
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 animate-fade-in">
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl gradient-primary">
            <Briefcase className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Job Opportunities</h1>
            <p className="text-muted-foreground">Find jobs that match your skills</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {mockJobs.map((job, index) => (
          <Card key={index} className="animate-slide-up hover:shadow-elegant transition-smooth cursor-pointer" style={{ animationDelay: `${index * 0.1}s` }}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle>{job.title}</CardTitle>
                  <CardDescription className="mt-2">{job.company}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  {job.location}
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <DollarSign className="w-4 h-4" />
                  {job.salary}
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill, idx) => (
                  <Badge key={idx} variant="secondary">{skill}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Jobs;
