import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calculator, Briefcase, GraduationCap, FileText, TrendingUp, Target, Sparkles, ArrowRight } from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: Calculator,
      title: 'Salary Calculator',
      description: 'Get accurate salary estimates based on your skills, experience, and location with AI-powered analysis.',
      link: '/salary-calculator',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Target,
      title: 'Skill Gap Analysis',
      description: 'Identify missing skills for your dream job and get personalized recommendations to bridge the gap.',
      link: '/dashboard',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: GraduationCap,
      title: 'Learning Resources',
      description: 'Access curated courses, articles, and projects tailored to your career goals and skill level.',
      link: '/learning',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: FileText,
      title: 'ATS Resume Scorer',
      description: 'Optimize your resume for Applicant Tracking Systems with detailed feedback and improvement suggestions.',
      link: '/resume',
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: Briefcase,
      title: 'Job Matching',
      description: 'Find jobs that match your skills and get probability predictions for your success.',
      link: '/jobs',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: TrendingUp,
      title: 'Career Analytics',
      description: 'Track your progress, predict career growth, and plan your path to success with data-driven insights.',
      link: '/dashboard',
      gradient: 'from-pink-500 to-rose-500'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden gradient-subtle py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center animate-fade-in">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="flex items-center justify-center w-16 h-16 rounded-2xl gradient-primary shadow-elegant">
                <Sparkles className="w-9 h-9 text-white" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Job Jugaad</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Your AI-powered career development platform. Identify skill gaps, optimize your resume, 
              calculate your worth, and accelerate your career growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/dashboard">
                <Button size="lg" className="gap-2 shadow-elegant">
                  Get Started
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link to="/salary-calculator">
                <Button size="lg" variant="outline" className="gap-2">
                  <Calculator className="w-5 h-5" />
                  Try Salary Calculator
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Powerful Features for Your Career
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to take control of your career development journey
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Link key={index} to={feature.link}>
                  <Card className="h-full transition-smooth hover:shadow-elegant hover:-translate-y-1 cursor-pointer group">
                    <CardHeader>
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-smooth`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 gradient-primary">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Accelerate Your Career?
          </h2>
          <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of professionals who are using Job Jugaad to identify skill gaps, 
            optimize their resumes, and land their dream jobs.
          </p>
          <Link to="/dashboard">
            <Button size="lg" variant="secondary" className="gap-2 shadow-glow">
              Start Your Journey
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="container mx-auto max-w-6xl text-center text-muted-foreground">
          <p>2025 Job Jugaad</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
