import type { ReactNode } from 'react';
import Home from './pages/Home';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SalaryCalculator from './pages/SalaryCalculator';
import Profile from './pages/Profile';
import Jobs from './pages/Jobs';
import Learning from './pages/Learning';
import Resume from './pages/Resume';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />,
    visible: true
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />,
    visible: true
  },
  {
    name: 'Salary Calculator',
    path: '/salary-calculator',
    element: <SalaryCalculator />,
    visible: true
  },
  {
    name: 'Jobs',
    path: '/jobs',
    element: <Jobs />,
    visible: true
  },
  {
    name: 'Learning',
    path: '/learning',
    element: <Learning />,
    visible: true
  },
  {
    name: 'Resume',
    path: '/resume',
    element: <Resume />,
    visible: true
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Profile />,
    visible: true
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false
  }
];

export default routes;
