export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  phone: string | null;
  email: string | null;
  full_name: string | null;
  nickname: string | null;
  avatar_url: string | null;
  role: UserRole;
  location_country: string | null;
  location_city: string | null;
  timezone: string;
  communication_skill: number | null;
  coding_fluency_score: number | null;
  open_to_relocate: boolean;
  created_at: string;
  updated_at: string;
}

export interface Experience {
  id: string;
  user_id: string;
  company_name: string;
  position: string;
  seniority_level: string | null;
  industry: string | null;
  company_size: string | null;
  start_date: string;
  end_date: string | null;
  is_current: boolean;
  description: string | null;
  created_at: string;
}

export interface Education {
  id: string;
  user_id: string;
  degree: string;
  field_of_study: string;
  institution: string;
  graduation_year: number | null;
  gpa: number | null;
  created_at: string;
}

export interface Skill {
  id: string;
  user_id: string;
  skill_name: string;
  skill_category: string | null;
  proficiency_level: number;
  years_experience: number | null;
  created_at: string;
}

export interface Certification {
  id: string;
  user_id: string;
  certification_name: string;
  issuing_organization: string | null;
  issue_date: string | null;
  expiry_date: string | null;
  credential_id: string | null;
  credential_url: string | null;
  created_at: string;
}

export interface JobTemplate {
  id: string;
  title: string;
  location_country: string | null;
  location_city: string | null;
  industry: string | null;
  company_size: string | null;
  description: string | null;
  required_skills: SkillRequirement[];
  preferred_skills: SkillRequirement[];
  min_experience_years: number | null;
  max_experience_years: number | null;
  salary_min: number | null;
  salary_max: number | null;
  salary_currency: string;
  is_active: boolean;
  created_at: string;
}

export interface SkillRequirement {
  skill: string;
  level: number;
}

export interface SalaryMarketData {
  id: string;
  job_title: string;
  location_country: string;
  location_city: string | null;
  experience_min: number | null;
  experience_max: number | null;
  salary_median: number;
  salary_p25: number | null;
  salary_p75: number | null;
  salary_currency: string;
  sample_size: number | null;
  data_date: string | null;
  created_at: string;
}

export interface Resume {
  id: string;
  user_id: string;
  file_name: string;
  file_path: string;
  file_size: number | null;
  file_type: string | null;
  parsed_text: string | null;
  parsed_sections: ParsedSections | null;
  ats_score: number | null;
  ats_analysis: ATSAnalysis | null;
  last_scanned_at: string | null;
  created_at: string;
}

export interface ParsedSections {
  experience?: string[];
  education?: string[];
  skills?: string[];
  projects?: string[];
  summary?: string;
}

export interface ATSAnalysis {
  missing_keywords: string[];
  format_warnings: string[];
  section_completeness: {
    [key: string]: boolean;
  };
  suggestions: string[];
}

export interface LearningResource {
  id: string;
  title: string;
  resource_type: string;
  url: string | null;
  description: string | null;
  provider: string | null;
  covered_skills: string[];
  difficulty_level: number;
  estimated_hours: number | null;
  is_free: boolean;
  rating: number | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  notification_type: string;
  channel: string;
  title: string;
  content: string;
  status: string;
  sent_at: string | null;
  read_at: string | null;
  created_at: string;
}

export interface UserPreferences {
  id: string;
  user_id: string;
  notification_email: boolean;
  notification_sms: boolean;
  notification_push: boolean;
  notification_frequency: string;
  job_alert_enabled: boolean;
  learning_reminder_enabled: boolean;
  theme: string;
  language: string;
  created_at: string;
  updated_at: string;
}

export interface SalaryEstimate {
  id: string;
  user_id: string;
  role_target: string;
  location_country: string;
  location_city: string | null;
  years_experience: number;
  education_degree: string | null;
  education_field: string | null;
  previous_companies: PreviousCompany[];
  coding_languages: CodingLanguage[];
  coding_fluency_score: number | null;
  communication_skill: number | null;
  industry: string | null;
  certifications: string[];
  open_to_relocate: boolean;
  estimated_salary: number | null;
  salary_range_low: number | null;
  salary_range_high: number | null;
  median_salary: number | null;
  percentile: number | null;
  confidence_score: number | null;
  feature_breakdown: FeatureImpact[];
  created_at: string;
}

export interface PreviousCompany {
  name: string;
  seniority: string;
}

export interface CodingLanguage {
  name: string;
  level: number;
}

export interface FeatureImpact {
  factor: string;
  impact_percent: number;
}

export interface SalaryEstimateRequest {
  previous_companies: PreviousCompany[];
  education: {
    degree: string;
    field: string;
  };
  years_experience: number;
  role_target: string;
  coding_languages: CodingLanguage[];
  coding_fluency_score: number;
  communication_skill: number;
  location_country: string;
  location_city?: string;
  industry?: string;
  certifications?: string[];
  open_to_relocate: boolean;
}

export interface SalaryEstimateResponse {
  role: string;
  location: string;
  median_salary: number;
  salary_range: {
    low: number;
    high: number;
  };
  estimated_salary: number;
  percentile: number;
  feature_breakdown: FeatureImpact[];
  confidence: number;
  currency: string;
}
