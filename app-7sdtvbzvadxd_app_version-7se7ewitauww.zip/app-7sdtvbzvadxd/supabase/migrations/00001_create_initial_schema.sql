/*
# Job Jugaad Initial Database Schema

## 1. Plain English Explanation
This migration creates the foundational database structure for Job Jugaad, a career development platform.
It includes user profiles, work experience, education, skills, job templates, salary market data, resumes,
learning resources, notifications, and user preferences.

## 2. Table List & Column Descriptions

### profiles
- `id` (uuid, primary key, references auth.users) - User unique identifier
- `phone` (text, unique) - User phone number
- `email` (text, unique) - User email address
- `full_name` (text) - User's full name
- `nickname` (text) - Display name
- `avatar_url` (text) - Profile picture URL
- `role` (user_role enum: 'user', 'admin') - User role
- `location_country` (text) - Country of residence
- `location_city` (text) - City of residence
- `timezone` (text) - User timezone
- `communication_skill` (integer, 1-5) - Communication ability rating
- `coding_fluency_score` (integer, 0-100) - Overall coding proficiency
- `open_to_relocate` (boolean) - Willingness to relocate
- `created_at` (timestamptz) - Account creation timestamp
- `updated_at` (timestamptz) - Last update timestamp

### experiences
- `id` (uuid, primary key) - Experience record ID
- `user_id` (uuid, references profiles) - User who owns this experience
- `company_name` (text, not null) - Company name
- `position` (text, not null) - Job title/position
- `seniority_level` (text) - Seniority level (e.g., Junior, Senior, Lead)
- `industry` (text) - Industry sector
- `company_size` (text) - Company size category
- `start_date` (date, not null) - Employment start date
- `end_date` (date) - Employment end date (null if current)
- `is_current` (boolean) - Whether this is current employment
- `description` (text) - Job description and responsibilities
- `created_at` (timestamptz) - Record creation timestamp

### education
- `id` (uuid, primary key) - Education record ID
- `user_id` (uuid, references profiles) - User who owns this education
- `degree` (text, not null) - Degree type (e.g., B.Tech, M.S., Ph.D.)
- `field_of_study` (text, not null) - Major/field of study
- `institution` (text, not null) - University/institution name
- `graduation_year` (integer) - Year of graduation
- `gpa` (numeric) - Grade point average
- `created_at` (timestamptz) - Record creation timestamp

### skills
- `id` (uuid, primary key) - Skill record ID
- `user_id` (uuid, references profiles) - User who owns this skill
- `skill_name` (text, not null) - Name of the skill
- `skill_category` (text) - Category (e.g., Programming, Framework, Tool)
- `proficiency_level` (integer, 1-5) - Skill proficiency rating
- `years_experience` (numeric) - Years of experience with this skill
- `created_at` (timestamptz) - Record creation timestamp

### certifications
- `id` (uuid, primary key) - Certification record ID
- `user_id` (uuid, references profiles) - User who owns this certification
- `certification_name` (text, not null) - Name of certification
- `issuing_organization` (text) - Organization that issued the certification
- `issue_date` (date) - Date certification was issued
- `expiry_date` (date) - Expiration date (if applicable)
- `credential_id` (text) - Credential/certificate ID
- `credential_url` (text) - URL to verify certification
- `created_at` (timestamptz) - Record creation timestamp

### job_templates
- `id` (uuid, primary key) - Job template ID
- `title` (text, not null) - Job title
- `location_country` (text) - Country where job is located
- `location_city` (text) - City where job is located
- `industry` (text) - Industry sector
- `company_size` (text) - Company size category
- `description` (text) - Full job description
- `required_skills` (jsonb) - Required skills with proficiency levels
- `preferred_skills` (jsonb) - Preferred/bonus skills
- `min_experience_years` (integer) - Minimum years of experience required
- `max_experience_years` (integer) - Maximum years of experience
- `salary_min` (integer) - Minimum salary range
- `salary_max` (integer) - Maximum salary range
- `salary_currency` (text) - Currency code (e.g., USD, INR)
- `is_active` (boolean) - Whether template is active
- `created_at` (timestamptz) - Record creation timestamp

### salary_market_data
- `id` (uuid, primary key) - Market data record ID
- `job_title` (text, not null) - Job title
- `location_country` (text, not null) - Country
- `location_city` (text) - City (optional for broader data)
- `experience_min` (integer) - Minimum experience years for this bracket
- `experience_max` (integer) - Maximum experience years for this bracket
- `salary_median` (integer, not null) - Median salary
- `salary_p25` (integer) - 25th percentile salary
- `salary_p75` (integer) - 75th percentile salary
- `salary_currency` (text) - Currency code
- `sample_size` (integer) - Number of data points
- `data_date` (date) - Date of data collection
- `created_at` (timestamptz) - Record creation timestamp

### resumes
- `id` (uuid, primary key) - Resume record ID
- `user_id` (uuid, references profiles) - User who owns this resume
- `file_name` (text, not null) - Original file name
- `file_path` (text, not null) - Storage path in Supabase Storage
- `file_size` (integer) - File size in bytes
- `file_type` (text) - MIME type
- `parsed_text` (text) - Extracted text content
- `parsed_sections` (jsonb) - Structured sections (experience, education, skills, etc.)
- `ats_score` (integer) - ATS score (0-100)
- `ats_analysis` (jsonb) - Detailed ATS analysis results
- `last_scanned_at` (timestamptz) - Last time resume was analyzed
- `created_at` (timestamptz) - Upload timestamp

### learning_resources
- `id` (uuid, primary key) - Resource ID
- `title` (text, not null) - Resource title
- `resource_type` (text, not null) - Type: course, article, video, project
- `url` (text) - Link to resource
- `description` (text) - Resource description
- `provider` (text) - Content provider (e.g., Coursera, YouTube)
- `covered_skills` (jsonb) - Array of skills this resource covers
- `difficulty_level` (integer, 1-5) - Difficulty rating
- `estimated_hours` (numeric) - Estimated time to complete
- `is_free` (boolean) - Whether resource is free
- `rating` (numeric) - User rating (0-5)
- `created_at` (timestamptz) - Record creation timestamp

### notifications
- `id` (uuid, primary key) - Notification ID
- `user_id` (uuid, references profiles) - Recipient user
- `notification_type` (text, not null) - Type: job_match, webinar, hackathon, skill_opportunity, milestone
- `channel` (text, not null) - Delivery channel: email, sms, push
- `title` (text, not null) - Notification title
- `content` (text, not null) - Notification content
- `status` (text) - Status: pending, sent, failed, read
- `sent_at` (timestamptz) - When notification was sent
- `read_at` (timestamptz) - When notification was read
- `created_at` (timestamptz) - Record creation timestamp

### user_preferences
- `id` (uuid, primary key) - Preference record ID
- `user_id` (uuid, references profiles, unique) - User these preferences belong to
- `notification_email` (boolean) - Enable email notifications
- `notification_sms` (boolean) - Enable SMS notifications
- `notification_push` (boolean) - Enable push notifications
- `notification_frequency` (text) - Frequency: immediate, daily, weekly
- `job_alert_enabled` (boolean) - Enable job match alerts
- `learning_reminder_enabled` (boolean) - Enable learning reminders
- `theme` (text) - UI theme preference: light, dark, auto
- `language` (text) - Preferred language
- `created_at` (timestamptz) - Record creation timestamp
- `updated_at` (timestamptz) - Last update timestamp

### salary_estimates
- `id` (uuid, primary key) - Estimate record ID
- `user_id` (uuid, references profiles) - User who requested estimate
- `role_target` (text, not null) - Target job role
- `location_country` (text, not null) - Target country
- `location_city` (text) - Target city
- `years_experience` (integer, not null) - Years of experience
- `education_degree` (text) - Highest degree
- `education_field` (text) - Field of study
- `previous_companies` (jsonb) - Array of previous companies with seniority
- `coding_languages` (jsonb) - Array of languages with proficiency
- `coding_fluency_score` (integer) - Overall coding score
- `communication_skill` (integer) - Communication rating
- `industry` (text) - Target industry
- `certifications` (jsonb) - Array of certifications
- `open_to_relocate` (boolean) - Relocation willingness
- `estimated_salary` (integer) - Calculated salary estimate
- `salary_range_low` (integer) - Lower bound of range
- `salary_range_high` (integer) - Upper bound of range
- `median_salary` (integer) - Market median
- `percentile` (integer) - Percentile ranking
- `confidence_score` (integer) - Confidence in estimate (0-100)
- `feature_breakdown` (jsonb) - Impact of each factor
- `created_at` (timestamptz) - Estimate timestamp

## 3. Security Changes
- Enable RLS on all tables
- Create admin helper function to check user role
- Profiles table:
  - Admins have full access
  - Users can view their own profile
  - Users can update their own profile (except role field)
- All user-owned tables (experiences, education, skills, etc.):
  - Admins have full access
  - Users can manage their own records
- Public read access for:
  - job_templates (active only)
  - salary_market_data
  - learning_resources
- Notifications and preferences:
  - Users can only access their own records
  - Admins have full access

## 4. Notes
- First registered user becomes admin automatically
- All tables use UUID primary keys
- Timestamps use timestamptz for timezone awareness
- JSONB used for flexible structured data
- Indexes added for common query patterns
*/

-- Create ENUM types
CREATE TYPE user_role AS ENUM ('user', 'admin');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  phone text UNIQUE,
  email text UNIQUE,
  full_name text,
  nickname text,
  avatar_url text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  location_country text,
  location_city text,
  timezone text DEFAULT 'UTC',
  communication_skill integer CHECK (communication_skill >= 1 AND communication_skill <= 5),
  coding_fluency_score integer CHECK (coding_fluency_score >= 0 AND coding_fluency_score <= 100),
  open_to_relocate boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create experiences table
CREATE TABLE IF NOT EXISTS experiences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  company_name text NOT NULL,
  position text NOT NULL,
  seniority_level text,
  industry text,
  company_size text,
  start_date date NOT NULL,
  end_date date,
  is_current boolean DEFAULT false,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create education table
CREATE TABLE IF NOT EXISTS education (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  degree text NOT NULL,
  field_of_study text NOT NULL,
  institution text NOT NULL,
  graduation_year integer,
  gpa numeric,
  created_at timestamptz DEFAULT now()
);

-- Create skills table
CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  skill_name text NOT NULL,
  skill_category text,
  proficiency_level integer CHECK (proficiency_level >= 1 AND proficiency_level <= 5),
  years_experience numeric,
  created_at timestamptz DEFAULT now()
);

-- Create certifications table
CREATE TABLE IF NOT EXISTS certifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  certification_name text NOT NULL,
  issuing_organization text,
  issue_date date,
  expiry_date date,
  credential_id text,
  credential_url text,
  created_at timestamptz DEFAULT now()
);

-- Create job_templates table
CREATE TABLE IF NOT EXISTS job_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  location_country text,
  location_city text,
  industry text,
  company_size text,
  description text,
  required_skills jsonb DEFAULT '[]'::jsonb,
  preferred_skills jsonb DEFAULT '[]'::jsonb,
  min_experience_years integer,
  max_experience_years integer,
  salary_min integer,
  salary_max integer,
  salary_currency text DEFAULT 'USD',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create salary_market_data table
CREATE TABLE IF NOT EXISTS salary_market_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_title text NOT NULL,
  location_country text NOT NULL,
  location_city text,
  experience_min integer,
  experience_max integer,
  salary_median integer NOT NULL,
  salary_p25 integer,
  salary_p75 integer,
  salary_currency text DEFAULT 'USD',
  sample_size integer,
  data_date date,
  created_at timestamptz DEFAULT now()
);

-- Create resumes table
CREATE TABLE IF NOT EXISTS resumes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  file_name text NOT NULL,
  file_path text NOT NULL,
  file_size integer,
  file_type text,
  parsed_text text,
  parsed_sections jsonb,
  ats_score integer CHECK (ats_score >= 0 AND ats_score <= 100),
  ats_analysis jsonb,
  last_scanned_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create learning_resources table
CREATE TABLE IF NOT EXISTS learning_resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  resource_type text NOT NULL,
  url text,
  description text,
  provider text,
  covered_skills jsonb DEFAULT '[]'::jsonb,
  difficulty_level integer CHECK (difficulty_level >= 1 AND difficulty_level <= 5),
  estimated_hours numeric,
  is_free boolean DEFAULT true,
  rating numeric CHECK (rating >= 0 AND rating <= 5),
  created_at timestamptz DEFAULT now()
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  notification_type text NOT NULL,
  channel text NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  status text DEFAULT 'pending',
  sent_at timestamptz,
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create user_preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL UNIQUE,
  notification_email boolean DEFAULT true,
  notification_sms boolean DEFAULT false,
  notification_push boolean DEFAULT true,
  notification_frequency text DEFAULT 'immediate',
  job_alert_enabled boolean DEFAULT true,
  learning_reminder_enabled boolean DEFAULT true,
  theme text DEFAULT 'light',
  language text DEFAULT 'en',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create salary_estimates table
CREATE TABLE IF NOT EXISTS salary_estimates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  role_target text NOT NULL,
  location_country text NOT NULL,
  location_city text,
  years_experience integer NOT NULL,
  education_degree text,
  education_field text,
  previous_companies jsonb DEFAULT '[]'::jsonb,
  coding_languages jsonb DEFAULT '[]'::jsonb,
  coding_fluency_score integer,
  communication_skill integer,
  industry text,
  certifications jsonb DEFAULT '[]'::jsonb,
  open_to_relocate boolean DEFAULT false,
  estimated_salary integer,
  salary_range_low integer,
  salary_range_high integer,
  median_salary integer,
  percentile integer,
  confidence_score integer,
  feature_breakdown jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX idx_experiences_user_id ON experiences(user_id);
CREATE INDEX idx_education_user_id ON education(user_id);
CREATE INDEX idx_skills_user_id ON skills(user_id);
CREATE INDEX idx_certifications_user_id ON certifications(user_id);
CREATE INDEX idx_resumes_user_id ON resumes(user_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_salary_estimates_user_id ON salary_estimates(user_id);
CREATE INDEX idx_job_templates_active ON job_templates(is_active);
CREATE INDEX idx_salary_market_country_title ON salary_market_data(location_country, job_title);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE experiences ENABLE ROW LEVEL SECURITY;
ALTER TABLE education ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE certifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_market_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE resumes ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_estimates ENABLE ROW LEVEL SECURITY;

-- Create admin helper function
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Profiles policies
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id) 
  WITH CHECK (role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- Experiences policies
CREATE POLICY "Admins have full access to experiences" ON experiences
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own experiences" ON experiences
  FOR ALL USING (auth.uid() = user_id);

-- Education policies
CREATE POLICY "Admins have full access to education" ON education
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own education" ON education
  FOR ALL USING (auth.uid() = user_id);

-- Skills policies
CREATE POLICY "Admins have full access to skills" ON skills
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own skills" ON skills
  FOR ALL USING (auth.uid() = user_id);

-- Certifications policies
CREATE POLICY "Admins have full access to certifications" ON certifications
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own certifications" ON certifications
  FOR ALL USING (auth.uid() = user_id);

-- Job templates policies (public read for active templates)
CREATE POLICY "Anyone can view active job templates" ON job_templates
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage job templates" ON job_templates
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Salary market data policies (public read)
CREATE POLICY "Anyone can view salary market data" ON salary_market_data
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage salary market data" ON salary_market_data
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Resumes policies
CREATE POLICY "Admins have full access to resumes" ON resumes
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own resumes" ON resumes
  FOR ALL USING (auth.uid() = user_id);

-- Learning resources policies (public read)
CREATE POLICY "Anyone can view learning resources" ON learning_resources
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage learning resources" ON learning_resources
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

-- Notifications policies
CREATE POLICY "Admins have full access to notifications" ON notifications
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view their own notifications" ON notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON notifications
  FOR UPDATE USING (auth.uid() = user_id);

-- User preferences policies
CREATE POLICY "Admins have full access to preferences" ON user_preferences
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own preferences" ON user_preferences
  FOR ALL USING (auth.uid() = user_id);

-- Salary estimates policies
CREATE POLICY "Admins have full access to salary estimates" ON salary_estimates
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage their own salary estimates" ON salary_estimates
  FOR ALL USING (auth.uid() = user_id);

-- Create trigger function for new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  -- Only insert into profiles after user is confirmed
  IF OLD IS DISTINCT FROM NULL AND OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL THEN
    -- Count existing users in profiles
    SELECT COUNT(*) INTO user_count FROM profiles;
    
    -- Insert into profiles, first user gets admin role
    INSERT INTO profiles (id, phone, email, full_name, role)
    VALUES (
      NEW.id,
      NEW.phone,
      NEW.email,
      COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
      CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
    );
    
    -- Create default preferences for new user
    INSERT INTO user_preferences (user_id)
    VALUES (NEW.id);
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON user_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();