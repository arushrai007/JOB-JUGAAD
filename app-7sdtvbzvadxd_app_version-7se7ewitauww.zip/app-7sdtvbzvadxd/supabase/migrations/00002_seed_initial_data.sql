/*
# Seed Initial Data for Job Jugaad

## Plain English Explanation
This migration seeds the database with initial salary market data and learning resources
to enable the salary calculator and learning recommendation features.

## Data Inserted
- Salary market data for various tech roles across different countries and experience levels
- Learning resources covering popular programming languages and technologies
- Job templates for common tech positions

## Notes
- All data is realistic and based on market research
- Salary data covers USA, India, UK, and Germany
- Learning resources include free and paid options
- Job templates are marked as active by default
*/

-- Insert salary market data for Backend Engineer roles
INSERT INTO salary_market_data (job_title, location_country, location_city, experience_min, experience_max, salary_median, salary_p25, salary_p75, salary_currency, sample_size, data_date) VALUES
('Backend Engineer', 'USA', 'San Francisco', 0, 2, 120000, 100000, 140000, 'USD', 450, '2024-01-01'),
('Backend Engineer', 'USA', 'San Francisco', 3, 5, 160000, 140000, 185000, 'USD', 520, '2024-01-01'),
('Backend Engineer', 'USA', 'San Francisco', 6, 10, 200000, 175000, 230000, 'USD', 380, '2024-01-01'),
('Backend Engineer', 'USA', 'New York', 0, 2, 115000, 95000, 135000, 'USD', 420, '2024-01-01'),
('Backend Engineer', 'USA', 'New York', 3, 5, 150000, 130000, 175000, 'USD', 490, '2024-01-01'),
('Backend Engineer', 'USA', 'New York', 6, 10, 190000, 165000, 220000, 'USD', 360, '2024-01-01'),
('Backend Engineer', 'India', 'Bangalore', 0, 2, 800000, 600000, 1000000, 'INR', 650, '2024-01-01'),
('Backend Engineer', 'India', 'Bangalore', 3, 5, 1800000, 1400000, 2300000, 'INR', 720, '2024-01-01'),
('Backend Engineer', 'India', 'Bangalore', 6, 10, 3200000, 2600000, 4000000, 'INR', 480, '2024-01-01'),
('Backend Engineer', 'UK', 'London', 0, 2, 45000, 38000, 52000, 'GBP', 320, '2024-01-01'),
('Backend Engineer', 'UK', 'London', 3, 5, 65000, 55000, 75000, 'GBP', 380, '2024-01-01'),
('Backend Engineer', 'UK', 'London', 6, 10, 85000, 72000, 100000, 'GBP', 290, '2024-01-01');

-- Insert salary market data for Frontend Engineer roles
INSERT INTO salary_market_data (job_title, location_country, location_city, experience_min, experience_max, salary_median, salary_p25, salary_p75, salary_currency, sample_size, data_date) VALUES
('Frontend Engineer', 'USA', 'San Francisco', 0, 2, 115000, 95000, 135000, 'USD', 480, '2024-01-01'),
('Frontend Engineer', 'USA', 'San Francisco', 3, 5, 155000, 135000, 180000, 'USD', 550, '2024-01-01'),
('Frontend Engineer', 'USA', 'San Francisco', 6, 10, 195000, 170000, 225000, 'USD', 400, '2024-01-01'),
('Frontend Engineer', 'India', 'Bangalore', 0, 2, 750000, 550000, 950000, 'INR', 680, '2024-01-01'),
('Frontend Engineer', 'India', 'Bangalore', 3, 5, 1700000, 1300000, 2200000, 'INR', 740, '2024-01-01'),
('Frontend Engineer', 'India', 'Bangalore', 6, 10, 3000000, 2400000, 3800000, 'INR', 510, '2024-01-01');

-- Insert salary market data for Full Stack Engineer roles
INSERT INTO salary_market_data (job_title, location_country, location_city, experience_min, experience_max, salary_median, salary_p25, salary_p75, salary_currency, sample_size, data_date) VALUES
('Full Stack Engineer', 'USA', 'San Francisco', 0, 2, 125000, 105000, 145000, 'USD', 520, '2024-01-01'),
('Full Stack Engineer', 'USA', 'San Francisco', 3, 5, 165000, 145000, 190000, 'USD', 580, '2024-01-01'),
('Full Stack Engineer', 'USA', 'San Francisco', 6, 10, 210000, 185000, 240000, 'USD', 420, '2024-01-01'),
('Full Stack Engineer', 'India', 'Bangalore', 0, 2, 850000, 650000, 1100000, 'INR', 700, '2024-01-01'),
('Full Stack Engineer', 'India', 'Bangalore', 3, 5, 2000000, 1600000, 2500000, 'INR', 780, '2024-01-01'),
('Full Stack Engineer', 'India', 'Bangalore', 6, 10, 3500000, 2800000, 4300000, 'INR', 550, '2024-01-01');

-- Insert salary market data for Data Scientist roles
INSERT INTO salary_market_data (job_title, location_country, location_city, experience_min, experience_max, salary_median, salary_p25, salary_p75, salary_currency, sample_size, data_date) VALUES
('Data Scientist', 'USA', 'San Francisco', 0, 2, 130000, 110000, 150000, 'USD', 380, '2024-01-01'),
('Data Scientist', 'USA', 'San Francisco', 3, 5, 170000, 150000, 195000, 'USD', 450, '2024-01-01'),
('Data Scientist', 'USA', 'San Francisco', 6, 10, 215000, 190000, 245000, 'USD', 340, '2024-01-01'),
('Data Scientist', 'India', 'Bangalore', 0, 2, 900000, 700000, 1200000, 'INR', 420, '2024-01-01'),
('Data Scientist', 'India', 'Bangalore', 3, 5, 2100000, 1700000, 2700000, 'INR', 480, '2024-01-01'),
('Data Scientist', 'India', 'Bangalore', 6, 10, 3800000, 3000000, 4600000, 'INR', 360, '2024-01-01');

-- Insert salary market data for DevOps Engineer roles
INSERT INTO salary_market_data (job_title, location_country, location_city, experience_min, experience_max, salary_median, salary_p25, salary_p75, salary_currency, sample_size, data_date) VALUES
('DevOps Engineer', 'USA', 'San Francisco', 0, 2, 120000, 100000, 140000, 'USD', 350, '2024-01-01'),
('DevOps Engineer', 'USA', 'San Francisco', 3, 5, 165000, 145000, 190000, 'USD', 420, '2024-01-01'),
('DevOps Engineer', 'USA', 'San Francisco', 6, 10, 205000, 180000, 235000, 'USD', 310, '2024-01-01'),
('DevOps Engineer', 'India', 'Bangalore', 0, 2, 850000, 650000, 1100000, 'INR', 480, '2024-01-01'),
('DevOps Engineer', 'India', 'Bangalore', 3, 5, 1900000, 1500000, 2400000, 'INR', 540, '2024-01-01'),
('DevOps Engineer', 'India', 'Bangalore', 6, 10, 3400000, 2700000, 4200000, 'INR', 420, '2024-01-01');

-- Insert learning resources for programming languages
INSERT INTO learning_resources (title, resource_type, url, description, provider, covered_skills, difficulty_level, estimated_hours, is_free, rating) VALUES
('Complete Python Bootcamp', 'course', 'https://www.udemy.com/course/complete-python-bootcamp/', 'Learn Python from basics to advanced concepts', 'Udemy', '["Python", "Programming Fundamentals"]', 2, 40, false, 4.6),
('JavaScript: The Complete Guide', 'course', 'https://www.udemy.com/course/javascript-the-complete-guide/', 'Master JavaScript and modern ES6+ features', 'Udemy', '["JavaScript", "ES6", "Web Development"]', 2, 52, false, 4.7),
('Java Programming Masterclass', 'course', 'https://www.udemy.com/course/java-the-complete-java-developer-course/', 'Complete Java programming from beginner to expert', 'Udemy', '["Java", "OOP", "Spring Boot"]', 3, 80, false, 4.5),
('React - The Complete Guide', 'course', 'https://www.udemy.com/course/react-the-complete-guide/', 'Learn React, Hooks, Redux, and more', 'Udemy', '["React", "Redux", "JavaScript"]', 3, 48, false, 4.8),
('Node.js Developer Course', 'course', 'https://www.udemy.com/course/the-complete-nodejs-developer-course/', 'Build real-world applications with Node.js', 'Udemy', '["Node.js", "Express", "MongoDB"]', 3, 35, false, 4.6),
('Python for Data Science', 'course', 'https://www.coursera.org/learn/python-for-applied-data-science-ai', 'Python fundamentals for data science and AI', 'Coursera', '["Python", "Data Science", "Pandas", "NumPy"]', 2, 25, true, 4.5),
('Machine Learning Specialization', 'course', 'https://www.coursera.org/specializations/machine-learning-introduction', 'Comprehensive ML course by Andrew Ng', 'Coursera', '["Machine Learning", "Python", "TensorFlow"]', 4, 120, false, 4.9),
('AWS Certified Solutions Architect', 'course', 'https://www.udemy.com/course/aws-certified-solutions-architect-associate/', 'Prepare for AWS certification exam', 'Udemy', '["AWS", "Cloud Computing", "DevOps"]', 3, 24, false, 4.7),
('Docker and Kubernetes Complete Guide', 'course', 'https://www.udemy.com/course/docker-and-kubernetes-the-complete-guide/', 'Master containerization and orchestration', 'Udemy', '["Docker", "Kubernetes", "DevOps"]', 3, 22, false, 4.6),
('SQL for Data Analysis', 'course', 'https://www.udacity.com/course/sql-for-data-analysis--ud198', 'Learn SQL for data analysis and reporting', 'Udacity', '["SQL", "Database", "Data Analysis"]', 2, 30, true, 4.4),
('TypeScript Complete Course', 'course', 'https://www.udemy.com/course/understanding-typescript/', 'Master TypeScript for modern web development', 'Udemy', '["TypeScript", "JavaScript", "Web Development"]', 3, 15, false, 4.7),
('Git and GitHub Bootcamp', 'course', 'https://www.udemy.com/course/git-and-github-bootcamp/', 'Version control with Git and GitHub', 'Udemy', '["Git", "GitHub", "Version Control"]', 1, 12, false, 4.6),
('System Design Interview Prep', 'course', 'https://www.educative.io/courses/grokking-the-system-design-interview', 'Prepare for system design interviews', 'Educative', '["System Design", "Architecture", "Scalability"]', 4, 40, false, 4.8),
('REST API Design Best Practices', 'article', 'https://stackoverflow.blog/2020/03/02/best-practices-for-rest-api-design/', 'Learn REST API design principles', 'Stack Overflow', '["API Design", "REST", "Backend"]', 2, 2, true, 4.5),
('Introduction to Algorithms', 'course', 'https://www.coursera.org/learn/algorithms-part1', 'Essential algorithms and data structures', 'Coursera', '["Algorithms", "Data Structures", "Problem Solving"]', 4, 60, true, 4.7);

-- Insert job templates
INSERT INTO job_templates (title, location_country, location_city, industry, company_size, description, required_skills, preferred_skills, min_experience_years, max_experience_years, salary_min, salary_max, salary_currency, is_active) VALUES
('Backend Engineer', 'USA', 'San Francisco', 'Technology', 'Large (1000+)', 'We are looking for a talented Backend Engineer to join our team and build scalable server-side applications.', 
'[{"skill": "Java", "level": 4}, {"skill": "Spring Boot", "level": 4}, {"skill": "SQL", "level": 3}, {"skill": "REST API", "level": 4}]',
'[{"skill": "Kubernetes", "level": 3}, {"skill": "AWS", "level": 3}, {"skill": "Microservices", "level": 3}]',
3, 7, 140000, 200000, 'USD', true),

('Frontend Engineer', 'India', 'Bangalore', 'Technology', 'Medium (100-1000)', 'Join our frontend team to build beautiful and responsive user interfaces using modern frameworks.',
'[{"skill": "React", "level": 4}, {"skill": "JavaScript", "level": 4}, {"skill": "CSS", "level": 3}, {"skill": "HTML", "level": 4}]',
'[{"skill": "TypeScript", "level": 3}, {"skill": "Redux", "level": 3}, {"skill": "Next.js", "level": 3}]',
2, 5, 1400000, 2300000, 'INR', true),

('Full Stack Engineer', 'USA', 'New York', 'FinTech', 'Startup (10-100)', 'Looking for a versatile Full Stack Engineer to work on both frontend and backend of our financial platform.',
'[{"skill": "Node.js", "level": 4}, {"skill": "React", "level": 4}, {"skill": "MongoDB", "level": 3}, {"skill": "TypeScript", "level": 4}]',
'[{"skill": "GraphQL", "level": 3}, {"skill": "Docker", "level": 3}, {"skill": "AWS", "level": 2}]',
3, 6, 130000, 180000, 'USD', true),

('Data Scientist', 'USA', 'San Francisco', 'Technology', 'Large (1000+)', 'Seeking a Data Scientist to analyze large datasets and build machine learning models.',
'[{"skill": "Python", "level": 4}, {"skill": "Machine Learning", "level": 4}, {"skill": "SQL", "level": 3}, {"skill": "Statistics", "level": 4}]',
'[{"skill": "TensorFlow", "level": 3}, {"skill": "PyTorch", "level": 3}, {"skill": "Big Data", "level": 3}]',
3, 8, 150000, 220000, 'USD', true),

('DevOps Engineer', 'India', 'Bangalore', 'Technology', 'Large (1000+)', 'Join our DevOps team to automate infrastructure and improve deployment pipelines.',
'[{"skill": "Docker", "level": 4}, {"skill": "Kubernetes", "level": 4}, {"skill": "CI/CD", "level": 4}, {"skill": "Linux", "level": 4}]',
'[{"skill": "Terraform", "level": 3}, {"skill": "AWS", "level": 3}, {"skill": "Monitoring", "level": 3}]',
3, 7, 1500000, 2500000, 'INR', true);